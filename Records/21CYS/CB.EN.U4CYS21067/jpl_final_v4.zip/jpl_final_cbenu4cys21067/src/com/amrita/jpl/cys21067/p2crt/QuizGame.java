package com.amrita.jpl.cys21067.p2crt;

/**
 * The Abstract Class and Interface of the Quiz Game
 *
 * @author Dharmik S
 * @version 1.0
 */
abstract class QuizGame {
    void startGame(){
        System.out.println("Game Started");
    }
    abstract void askQuestion();

    abstract void evaluateAnswer(String answer);
}

interface QuizGameListener{
    void onQuestionAsked(String question);

    void onAnswerEvaluated(boolean isCorrect);
}