package com.amrita.jpl.cys21067.practice.problems;

/**
 * The Hello class prints "Hello world!" to the console.
 */
public class hello {

    /**
     * The main method is the entry point of the program.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
