package com.amrita.jpl.cbenu4cys21067.endsem;
public interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void displayAllFiles();
}