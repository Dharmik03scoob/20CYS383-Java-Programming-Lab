package com.amrita.jpl.cbenu4cys21067.endsem;
public class Main {
    public static void main(String[] args) {
        FileManagementSystemUI fileManagementSystemUI = new FileManagementSystemUI();
    }
}
