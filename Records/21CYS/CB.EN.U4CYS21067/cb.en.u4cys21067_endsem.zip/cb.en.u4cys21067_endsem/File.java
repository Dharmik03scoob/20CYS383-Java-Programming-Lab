package com.amrita.jpl.cbenu4cys21067.endsem;
public class File {
    private String fileName;
    private String fileSize;

    public File(String fileName, String fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    // Getters and setters
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public void displayFileDetails() {
        System.out.println("File Name: " + fileName);
        System.out.println("File Size: " + fileSize);
    }

}
