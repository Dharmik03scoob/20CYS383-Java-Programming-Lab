package com.amrita.jpl.cbenu4cys21067.endsem;
public class Document extends File {
    private String documentType;

    public Document(String fileName, String fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    // Getters and setters
    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }
}
