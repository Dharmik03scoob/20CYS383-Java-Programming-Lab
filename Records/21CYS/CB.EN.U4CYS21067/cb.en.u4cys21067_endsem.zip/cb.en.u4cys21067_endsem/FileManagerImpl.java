package com.amrita.jpl.cbenu4cys21067.endsem;
import java.util.ArrayList;

public class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        this.files = new ArrayList<>();
    }

    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            File file = files.get(i);
            if (file.getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    @Override
    public void displayAllFiles() {
        for (File file : files) {
            file.displayFileDetails();
            System.out.println();
        }
    }
}
